package G3D;

public interface TextSerializable {
    public void serialize(TextOutput out);
}
