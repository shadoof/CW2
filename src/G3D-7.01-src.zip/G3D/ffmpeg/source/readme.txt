The .tar.bz2 file contains the bare sources of the nightly Subversion snapshot from the FFmpeg website.

http://ffmpeg.mplayerhq.hu/download.html

The current source was downloaded on 7/21/2008.

