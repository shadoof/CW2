package G3D;

public interface BinarySerializable {
    public void serialize(BinaryOutput output);
}
