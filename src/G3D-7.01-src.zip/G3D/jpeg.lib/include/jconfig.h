#ifdef __APPLE__
#    include "jconfig-osx.h"
#else
#    include "jconfig-win.h"
#endif
