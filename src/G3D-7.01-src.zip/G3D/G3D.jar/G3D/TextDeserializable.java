package G3D;

public interface TextDeserializable {
    public void deserialize(TextInput t);
}
